import { articleItem } from './articleInterface';

export interface AItemProp {
  data: articleItem;
  index: number;
  onClick: any;
}
